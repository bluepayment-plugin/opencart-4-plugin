<?php

namespace BluePayment\Service\Itn\Result;

abstract class ITNResponseType
{

}
