<?php

namespace Opencart\System\Library\BluePayment\Service\Itn\Result;

abstract class ITNResponseType
{

}
