<?php

namespace Opencart\Admin\Model\Extension\BluePayment\Payment;

class ModelPaymentBluepaymentGateway extends \Opencart\System\Engine\Model
{
    public function synchronize()
    {
        var_dump('synchronized');
        die;
    }
}
