<?php

class BluePaymentGateway extends \Opencart\System\Engine\Model
{
    public function synchronize()
    {
        var_dump('synchronized');
        die;
    }
}